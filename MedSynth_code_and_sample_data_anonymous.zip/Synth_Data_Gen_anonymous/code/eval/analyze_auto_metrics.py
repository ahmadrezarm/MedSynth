import pandas as pd
import numpy as np


df_aci= pd.read_csv("path", sep="|")
df_noteChat= pd.read_csv("path", sep="|")
df_MedSynth= pd.read_csv("path", sep="|")

for col in df_aci.columns:
    print(f"Aci Train  Model {col} Score is: {df_aci[col]}")
    print(f"NoteChat 4k Sample Train  Model {col} Score is: {df_noteChat[col]}")
    print(f"MedSynth 4k Samples Train Model {col} Score is: {df_MedSynth[col]}")
    print("*******************")

