#!/bin/bash
#SBATCH --job-name=N2D_Ah_Aci
#SBATCH --gres=gpu:a40:1
#SBATCH --mail-user=email@gmail.com  # Email address for notifications
#SBATCH --mail-type=ALL
#SBATCH --account=deadline
#SBATCH --qos=deadline
#SBATCH --time=16:00:00
#SBATCH -c 20
#SBATCH --mem=40G
#SBATCH --output=slurm-%j.out
#SBATCH --error=slurm-%j.err

echo "$(date): Job $SLURM_JOB_ID is allocated resource"

# Activate the conda environment

source /pkgs/anaconda3/bin/activate /h/username/.conda/envs/SynthDataGenEnv || conda activate /h/username/.conda/envs/SynthDataGenEnv


# put your command here
python /h/username/SynthDataGen/Synthetic_Data_Gen/code/eval/continous_eval/run_tuning.py

echo `date`: "Job $SLURM_JOB_ID finished running, exit code: $?"
