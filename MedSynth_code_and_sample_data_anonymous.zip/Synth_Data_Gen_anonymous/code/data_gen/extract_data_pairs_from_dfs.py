import pandas as pd
import os

directory = "path/data/output/notes_dial_pairs/"

all_files = os.listdir(directory)

filtered_files = [file for file in all_files if file.endswith("_with_dial.csv")]

df_list = []

for file in filtered_files:
    file_path = os.path.join(directory, file)
    df = pd.read_csv(file_path, sep="|") #usecols=["Role", "Disease Description", "Polished Note", "polished_dial"]
    df_list.append(df)


combined_df = pd.concat(df_list, ignore_index=True)
combined_df= combined_df[combined_df["Polished Note"] != "Rejected"]


combined_df.to_csv(f"{directory}_combined_with_dial.csv", sep="~", index=False)